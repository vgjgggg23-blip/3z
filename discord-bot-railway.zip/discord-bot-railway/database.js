const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'bot_data.db'));

db.exec(`
  CREATE TABLE IF NOT EXISTS messages_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT, guild_name TEXT,
    channel_id TEXT, channel_name TEXT,
    author_id TEXT, author_name TEXT,
    command TEXT, content TEXT,
    mention_type TEXT, status TEXT DEFAULT 'sent',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS scheduled_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT, channel_id TEXT,
    content TEXT, mention_type TEXT,
    schedule_time DATETIME,
    repeat_type TEXT DEFAULT 'once',
    status TEXT DEFAULT 'pending',
    created_by TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS reactions_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id TEXT, guild_id TEXT,
    channel_id TEXT, user_id TEXT,
    user_name TEXT, emoji TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS pinned_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT, channel_id TEXT,
    message_id TEXT, content TEXT,
    pinned_by TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS welcome_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT, user_id TEXT,
    user_name TEXT, type TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

module.exports = {
  logMessage(data) {
    return db.prepare(`
      INSERT INTO messages_log (guild_id,guild_name,channel_id,channel_name,author_id,author_name,command,content,mention_type,status)
      VALUES (?,?,?,?,?,?,?,?,?,?)
    `).run(data.guildId,data.guildName,data.channelId,data.channelName,data.authorId,data.authorName,data.command,data.content,data.mentionType,data.status);
  },
  getMessages(limit=100) {
    return db.prepare('SELECT * FROM messages_log ORDER BY created_at DESC LIMIT ?').all(limit);
  },
  addSchedule(data) {
    return db.prepare(`
      INSERT INTO scheduled_messages (guild_id,channel_id,content,mention_type,schedule_time,repeat_type,created_by)
      VALUES (?,?,?,?,?,?,?)
    `).run(data.guildId||'',data.channelId,data.content,data.mentionType||'',data.scheduleTime,data.repeatType||'once',data.createdBy||'dashboard');
  },
  getPendingSchedules() {
    return db.prepare("SELECT * FROM scheduled_messages WHERE status='pending' ORDER BY schedule_time ASC").all();
  },
  getAllSchedules() {
    return db.prepare('SELECT * FROM scheduled_messages ORDER BY created_at DESC').all();
  },
  updateScheduleStatus(id,status) {
    db.prepare('UPDATE scheduled_messages SET status=? WHERE id=?').run(status,id);
  },
  deleteSchedule(id) {
    db.prepare('DELETE FROM scheduled_messages WHERE id=?').run(id);
  },
  logReaction(data) {
    db.prepare(`INSERT INTO reactions_log (message_id,guild_id,channel_id,user_id,user_name,emoji) VALUES (?,?,?,?,?,?)`)
      .run(data.messageId,data.guildId,data.channelId,data.userId,data.userName,data.emoji);
  },
  logPin(data) {
    db.prepare(`INSERT INTO pinned_messages (guild_id,channel_id,message_id,content,pinned_by) VALUES (?,?,?,?,?)`)
      .run(data.guildId,data.channelId,data.messageId,data.content,data.pinnedBy);
  },
  logWelcome(data) {
    db.prepare(`INSERT INTO welcome_log (guild_id,user_id,user_name,type) VALUES (?,?,?,?)`)
      .run(data.guildId,data.userId,data.userName,data.type);
  },
  getStats() {
    return {
      totalMessages: db.prepare('SELECT COUNT(*) as c FROM messages_log').get().c,
      totalReactions: db.prepare('SELECT COUNT(*) as c FROM reactions_log').get().c,
      totalScheduled: db.prepare("SELECT COUNT(*) as c FROM scheduled_messages WHERE status='pending'").get().c,
      totalWelcome:   db.prepare("SELECT COUNT(*) as c FROM welcome_log WHERE type='join'").get().c,
      guilds:         db.prepare('SELECT DISTINCT guild_id,guild_name FROM messages_log').all(),
      topCommands:    db.prepare('SELECT command,COUNT(*) as count FROM messages_log GROUP BY command ORDER BY count DESC LIMIT 6').all(),
      last7Days:      db.prepare(`SELECT DATE(created_at) as date,COUNT(*) as count FROM messages_log WHERE created_at>=DATE('now','-7 days') GROUP BY DATE(created_at) ORDER BY date ASC`).all(),
      recentMessages: db.prepare('SELECT * FROM messages_log ORDER BY created_at DESC LIMIT 10').all(),
    };
  },
  db
};
