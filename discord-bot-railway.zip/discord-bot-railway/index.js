const { Client, GatewayIntentBits, Partials, EmbedBuilder, ActivityType } = require('discord.js');
const schedule = require('node-schedule');
const db = require('./database');

// =============================================
// ⚙️ الإعدادات — من ENV أو config.json
// =============================================
let config = {};
try { config = require('./config.json'); } catch {}

const CFG = {
  token:             process.env.BOT_TOKEN            || config.token,
  defaultChannelId:  process.env.DEFAULT_CHANNEL_ID   || config.defaultChannelId,
  dashboardPort:     process.env.PORT || process.env.DASHBOARD_PORT || config.dashboardPort || 3000,
  dashboardUser:     process.env.DASHBOARD_USER        || config.dashboardUser     || 'admin',
  dashboardPassword: process.env.DASHBOARD_PASSWORD    || config.dashboardPassword || '1234',
  webhookSecret:     process.env.WEBHOOK_SECRET        || config.webhookSecret     || 'secret',
  adminRoleIds:      process.env.ADMIN_ROLE_IDS
                       ? process.env.ADMIN_ROLE_IDS.split(',').map(s=>s.trim())
                       : (config.adminRoleIds || []),
  allowedChannelIds: process.env.ALLOWED_CHANNEL_IDS
                       ? process.env.ALLOWED_CHANNEL_IDS.split(',').map(s=>s.trim())
                       : (config.allowedChannelIds || []),
};

if (!CFG.token || CFG.token.includes('ضع_')) {
  console.error('❌ ما في BOT_TOKEN! حطه في Railway Environment Variables');
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildMembers,
  ],
  partials: [Partials.Channel, Partials.Message, Partials.Reaction],
});

client.once('ready', () => {
  console.log(`✅ البوت شغال: ${client.user.tag}`);
  console.log(`🌐 البورت: ${CFG.dashboardPort}`);
  client.user.setPresence({ activities:[{ name:'!help | Bot Pro', type: ActivityType.Watching }], status:'online' });
  schedule.scheduleJob('* * * * *', checkScheduledMessages);
});

function hasPermission(member) {
  if (!member) return false;
  if (!CFG.adminRoleIds || CFG.adminRoleIds.length === 0) return true;
  if (CFG.adminRoleIds[0].includes('ضع_')) return true;
  return CFG.adminRoleIds.some(id => member.roles.cache.has(id));
}

function isAllowedChannel(channelId) {
  if (!CFG.allowedChannelIds || CFG.allowedChannelIds.length === 0) return true;
  return CFG.allowedChannelIds.includes(channelId);
}

client.on('messageCreate', async (message) => {
  if (message.author.bot) return;
  if (!isAllowedChannel(message.channel.id)) return;
  const args = message.content.trim().split(/ +/);
  const command = args[0].toLowerCase();
  const validCmds = ['!send','!everyone','!here','!role','!user','!announce','!pin','!unpin','!giverole','!takerole','!schedule','!schedules','!delschedule','!stats','!help'];
  if (!validCmds.includes(command)) return;
  if (!hasPermission(message.member)) return message.reply('🚫 **ما عندك صلاحية!**');

  const info = { guildId: message.guild?.id||'DM', guildName: message.guild?.name||'DM', channelId: message.channel.id, channelName: message.channel.name||'DM', authorId: message.author.id, authorName: message.author.username };

  if (command==='!send') {
    const ch=args[1], txt=args.slice(2).join(' ');
    if (!ch||!txt) return message.reply('❌ `!send <ch_id> <رسالة>`');
    await sendAndLog(ch,txt,'',command,info,message);
  } else if (command==='!everyone') {
    const ch=args[1], txt=args.slice(2).join(' ');
    if (!ch||!txt) return message.reply('❌ `!everyone <ch_id> <رسالة>`');
    await sendAndLog(ch,txt,'@everyone',command,info,message);
  } else if (command==='!here') {
    const ch=args[1], txt=args.slice(2).join(' ');
    if (!ch||!txt) return message.reply('❌ `!here <ch_id> <رسالة>`');
    await sendAndLog(ch,txt,'@here',command,info,message);
  } else if (command==='!role') {
    const ch=args[1], rid=args[2], txt=args.slice(3).join(' ');
    if (!ch||!rid||!txt) return message.reply('❌ `!role <ch_id> <role_id> <رسالة>`');
    await sendAndLog(ch,txt,`role:${rid}`,command,info,message);
  } else if (command==='!user') {
    const ch=args[1], uid=args[2], txt=args.slice(3).join(' ');
    if (!ch||!uid||!txt) return message.reply('❌ `!user <ch_id> <user_id> <رسالة>`');
    await sendAndLog(ch,txt,`user:${uid}`,command,info,message);
  } else if (command==='!announce') {
    const ch=args[1], txt=args.slice(2).join(' ');
    if (!ch||!txt) return message.reply('❌ `!announce <ch_id> <رسالة>`');
    const embed=new EmbedBuilder().setColor('#5865f2').setTitle('📢 إعلان رسمي').setDescription(txt).setFooter({text:`بواسطة ${message.author.username}`}).setTimestamp();
    try { const c=await client.channels.fetch(ch); await c.send({content:'@everyone',embeds:[embed]}); message.react('✅'); db.logMessage({...info,command,content:txt,mentionType:'@everyone',status:'sent'}); } catch(e){ message.reply(`❌ ${e.message}`); }
  } else if (command==='!pin') {
    const ch=args[1], txt=args.slice(2).join(' ');
    if (!ch||!txt) return message.reply('❌ `!pin <ch_id> <رسالة>`');
    try { const c=await client.channels.fetch(ch); const s=await c.send(txt); await s.pin(); message.react('📌'); db.logPin({guildId:info.guildId,channelId:ch,messageId:s.id,content:txt,pinnedBy:message.author.username}); } catch(e){ message.reply(`❌ ${e.message}`); }
  } else if (command==='!unpin') {
    const ch=args[1], mid=args[2];
    if (!ch||!mid) return message.reply('❌ `!unpin <ch_id> <msg_id>`');
    try { const c=await client.channels.fetch(ch); const m=await c.messages.fetch(mid); await m.unpin(); message.react('✅'); } catch(e){ message.reply(`❌ ${e.message}`); }
  } else if (command==='!giverole') {
    const uid=args[1], rid=args[2];
    if (!uid||!rid) return message.reply('❌ `!giverole <user_id> <role_id>`');
    try { const m=await message.guild.members.fetch(uid); await m.roles.add(rid); message.reply(`✅ تم إعطاء الرتبة لـ **${m.user.username}**`); } catch(e){ message.reply(`❌ ${e.message}`); }
  } else if (command==='!takerole') {
    const uid=args[1], rid=args[2];
    if (!uid||!rid) return message.reply('❌ `!takerole <user_id> <role_id>`');
    try { const m=await message.guild.members.fetch(uid); await m.roles.remove(rid); message.reply(`✅ تم سحب الرتبة من **${m.user.username}**`); } catch(e){ message.reply(`❌ ${e.message}`); }
  } else if (command==='!schedule') {
    const ch=args[1], d=args[2], t=args[3], mn=args[4], txt=args.slice(5).join(' ');
    if (!ch||!d||!t||!txt) return message.reply('❌ `!schedule <ch_id> YYYY-MM-DD HH:MM @mention الرسالة`');
    const st=new Date(`${d}T${t}:00`);
    if (isNaN(st)||st<new Date()) return message.reply('❌ التاريخ غلط أو في الماضي!');
    db.addSchedule({guildId:info.guildId,channelId:ch,content:txt,mentionType:['@everyone','@here'].includes(mn)?mn:'',scheduleTime:st.toISOString(),createdBy:message.author.username});
    message.reply(`✅ جُدولت!\n📅 **${d} ${t}**\n💬 ${txt}`);
  } else if (command==='!schedules') {
    const list=db.getAllSchedules().slice(0,5);
    if (!list.length) return message.reply('📭 لا توجد جدولات.');
    message.reply('📅 **الجدولات:**\n\n'+list.map(s=>`**#${s.id}** | ${s.status} | ${new Date(s.schedule_time).toLocaleString('ar')}\n💬 ${s.content.slice(0,50)}`).join('\n\n'));
  } else if (command==='!delschedule') {
    const id=parseInt(args[1]);
    if (!id) return message.reply('❌ `!delschedule <ID>`');
    db.deleteSchedule(id); message.reply(`✅ حُذفت #${id}`);
  } else if (command==='!stats') {
    const s=db.getStats();
    message.reply(`📊 **إحصائيات:**\n📤 رسائل: **${s.totalMessages}**\n👍 تفاعلات: **${s.totalReactions}**\n📅 مجدولة: **${s.totalScheduled}**\n🌐 سيرفرات: **${s.guilds.length}**\n\n⚡ أكثر الأوامر:\n${s.topCommands.map(c=>`  ${c.command}: ${c.count}x`).join('\n')}`);
  } else if (command==='!help') {
    message.reply(`📖 **الأوامر:**\n\`!send <ch> <رسالة>\`\n\`!everyone <ch> <رسالة>\`\n\`!here <ch> <رسالة>\`\n\`!role <ch> <rid> <رسالة>\`\n\`!user <ch> <uid> <رسالة>\`\n\`!announce <ch> <رسالة>\`\n\`!pin <ch> <رسالة>\`\n\`!unpin <ch> <mid>\`\n\`!giverole <uid> <rid>\`\n\`!takerole <uid> <rid>\`\n\`!schedule <ch> DATE TIME MENTION رسالة\`\n\`!schedules\` | \`!delschedule <ID>\`\n\`!stats\``);
  }
});

client.on('messageReactionAdd', (reaction, user) => {
  if (user.bot) return;
  db.logReaction({ messageId: reaction.message.id, guildId: reaction.message.guild?.id||'DM', channelId: reaction.message.channel.id, userId: user.id, userName: user.username, emoji: reaction.emoji.name });
});

async function sendAndLog(channelId, content, mentionType, command, info, triggerMessage) {
  let final = content;
  if (mentionType==='@everyone') final=`@everyone ${content}`;
  else if (mentionType==='@here') final=`@here ${content}`;
  else if (mentionType?.startsWith('role:')) final=`<@&${mentionType.split(':')[1]}> ${content}`;
  else if (mentionType?.startsWith('user:')) final=`<@${mentionType.split(':')[1]}> ${content}`;
  try {
    const ch = await client.channels.fetch(channelId);
    await ch.send(final);
    if (triggerMessage) triggerMessage.react('✅');
    db.logMessage({...info, command, content: final, mentionType, status:'sent'});
    console.log(`[SEND] ✅ ${final.slice(0,60)}`);
  } catch(e) {
    db.logMessage({...info, command, content: final, mentionType, status:'failed'});
    if (triggerMessage) triggerMessage.reply(`❌ فشل: ${e.message}`);
  }
}

async function checkScheduledMessages() {
  const now = new Date();
  for (const msg of db.getPendingSchedules()) {
    if (new Date(msg.schedule_time) <= now) {
      await sendAndLog(msg.channel_id, msg.content, msg.mention_type, '!schedule',
        { guildId: msg.guild_id||'', guildName:'', channelId: msg.channel_id, channelName:'', authorId:'scheduler', authorName:'Scheduler' }, null);
      db.updateScheduleStatus(msg.id, 'sent');
    }
  }
}

module.exports = { client, sendAndLog, CFG };

client.login(CFG.token).catch(err => {
  console.error('❌ فشل تسجيل الدخول:', err.message);
  process.exit(1);
});
