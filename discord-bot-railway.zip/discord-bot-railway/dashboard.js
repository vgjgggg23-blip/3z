const express = require('express');
const basicAuth = require('express-basic-auth');
const cors = require('cors');
const db = require('./database');

// قراءة الإعدادات من ENV أو config.json
let config = {};
try { config = require('./config.json'); } catch {}
const CFG = {
  dashboardUser:     process.env.DASHBOARD_USER     || config.dashboardUser     || 'admin',
  dashboardPassword: process.env.DASHBOARD_PASSWORD || config.dashboardPassword || '1234',
  dashboardPort:     process.env.PORT || process.env.DASHBOARD_PORT || config.dashboardPort || 3000,
  webhookSecret:     process.env.WEBHOOK_SECRET     || config.webhookSecret     || 'secret',
};

const app = express();
app.use(express.json());
app.use(cors());

const auth = basicAuth({
  users: { [CFG.dashboardUser]: CFG.dashboardPassword },
  challenge: true,
  realm: 'Discord Bot Dashboard',
});

app.get('/', auth, (req, res) => res.send(html()));

app.get('/api/stats',     auth, (req,res) => res.json(db.getStats()));
app.get('/api/messages',  auth, (req,res) => res.json(db.getMessages(100)));
app.get('/api/schedules', auth, (req,res) => res.json(db.getAllSchedules()));

app.post('/api/send', auth, async (req,res) => {
  const { channelId, content, mentionType } = req.body;
  if (!channelId||!content) return res.status(400).json({error:'channelId و content مطلوبة'});
  try {
    const { client, sendAndLog } = require('./index');
    await sendAndLog(channelId, content, mentionType||'', '!dashboard',
      {guildId:'dashboard',guildName:'Dashboard',channelId,channelName:'',authorId:'dashboard',authorName:'Dashboard'}, null);
    res.json({success:true});
  } catch(e) { res.status(500).json({error:e.message}); }
});

app.post('/api/giverole', auth, async (req,res) => {
  const { guildId, userId, roleId } = req.body;
  if (!guildId||!userId||!roleId) return res.status(400).json({error:'guildId, userId, roleId مطلوبة'});
  try {
    const { client } = require('./index');
    const guild  = await client.guilds.fetch(guildId);
    const member = await guild.members.fetch(userId);
    await member.roles.add(roleId);
    res.json({success:true, username: member.user.username});
  } catch(e) { res.status(500).json({error:e.message}); }
});

app.post('/api/takerole', auth, async (req,res) => {
  const { guildId, userId, roleId } = req.body;
  if (!guildId||!userId||!roleId) return res.status(400).json({error:'guildId, userId, roleId مطلوبة'});
  try {
    const { client } = require('./index');
    const guild  = await client.guilds.fetch(guildId);
    const member = await guild.members.fetch(userId);
    await member.roles.remove(roleId);
    res.json({success:true, username: member.user.username});
  } catch(e) { res.status(500).json({error:e.message}); }
});

app.post('/api/schedule', auth, (req,res) => {
  const {channelId,content,mentionType,scheduleTime,repeatType} = req.body;
  if (!channelId||!content||!scheduleTime) return res.status(400).json({error:'channelId, content, scheduleTime مطلوبة'});
  try {
    const r = db.addSchedule({guildId:'',channelId,content,mentionType,scheduleTime,repeatType:'once',createdBy:'dashboard'});
    res.json({success:true,id:r.lastInsertRowid});
  } catch(e) { res.status(500).json({error:e.message}); }
});

app.delete('/api/schedule/:id', auth, (req,res) => {
  db.deleteSchedule(req.params.id);
  res.json({success:true});
});

app.post('/webhook', (req,res) => {
  const secret = req.headers['x-webhook-secret'];
  if (secret !== CFG.webhookSecret) return res.status(401).json({error:'Unauthorized'});
  const {channelId,content,mentionType} = req.body;
  if (!channelId||!content) return res.status(400).json({error:'channelId و content مطلوبة'});
  try {
    const {client,sendAndLog} = require('./index');
    sendAndLog(channelId,content,mentionType||'','webhook',
      {guildId:'webhook',guildName:'Webhook',channelId,channelName:'',authorId:'webhook',authorName:'Webhook'},null);
    res.json({success:true});
  } catch(e) { res.status(500).json({error:e.message}); }
});

app.listen(CFG.dashboardPort, () => {
  console.log(`🌐 Dashboard: http://localhost:${CFG.dashboardPort}`);
});

function html() { return `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Discord Bot Pro</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
<style>
:root{--bg:#0b0c14;--sur:#13141f;--card:#1a1c2e;--bor:#252840;--acc:#5865f2;--acc2:#7289da;--grn:#57f287;--red:#ed4245;--ylw:#faa61a;--cyn:#00d4ff;--txt:#e3e5f0;--mut:#6b6f96;--glow:rgba(88,101,242,.25)}
*{margin:0;padding:0;box-sizing:border-box}
body{background:var(--bg);font-family:'Cairo',sans-serif;color:var(--txt);min-height:100vh;display:flex}
body::before{content:'';position:fixed;inset:0;background-image:linear-gradient(rgba(88,101,242,.03) 1px,transparent 1px),linear-gradient(90deg,rgba(88,101,242,.03) 1px,transparent 1px);background-size:40px 40px;pointer-events:none;z-index:0}
.sidebar{width:230px;min-height:100vh;background:var(--sur);border-left:1px solid var(--bor);padding:20px 0;display:flex;flex-direction:column;position:fixed;right:0;top:0;bottom:0;z-index:10}
.logo{padding:0 18px 20px;border-bottom:1px solid var(--bor)}
.logo h2{font-size:17px;font-weight:900;background:linear-gradient(135deg,#fff,var(--acc2));-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.logo p{font-size:11px;color:var(--mut);margin-top:2px}
nav{padding:12px 0;flex:1}
.ni{display:flex;align-items:center;gap:9px;padding:10px 18px;cursor:pointer;color:var(--mut);font-size:13px;font-weight:600;transition:all .2s;border-right:3px solid transparent}
.ni:hover{color:var(--txt);background:rgba(88,101,242,.06)}
.ni.active{color:#fff;background:rgba(88,101,242,.12);border-right-color:var(--acc)}
.ni-icon{font-size:17px;width:22px;text-align:center}
.sf{padding:14px 18px;border-top:1px solid var(--bor);font-size:12px;color:var(--mut);display:flex;align-items:center;gap:6px}
.dot{width:7px;height:7px;border-radius:50%;background:var(--grn);box-shadow:0 0 7px var(--grn);animation:bl 2s infinite}
@keyframes bl{0%,100%{opacity:1}50%{opacity:.4}}
.main{margin-right:230px;flex:1;padding:26px;position:relative;z-index:1}
.ph{margin-bottom:24px}
.ph h1{font-size:22px;font-weight:900}
.ph p{color:var(--mut);font-size:13px;margin-top:3px}
.tab{display:none}.tab.active{display:block}
.sg{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:22px}
.sc{background:var(--card);border:1px solid var(--bor);border-radius:14px;padding:18px;position:relative;overflow:hidden;transition:transform .2s}
.sc:hover{transform:translateY(-2px)}
.sc::before{content:'';position:absolute;top:-25px;right:-25px;width:70px;height:70px;border-radius:50%;opacity:.1}
.sc.b::before{background:var(--acc)}.sc.g::before{background:var(--grn)}.sc.y::before{background:var(--ylw)}.sc.c::before{background:var(--cyn)}
.si{font-size:26px;margin-bottom:8px}.sn{font-size:30px;font-weight:900;line-height:1}.sl{font-size:11px;color:var(--mut);margin-top:3px}
.cr{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:22px}
.card{background:var(--card);border:1px solid var(--bor);border-radius:14px;padding:20px;margin-bottom:14px}
.ct{font-size:12px;font-weight:700;color:var(--mut);text-transform:uppercase;letter-spacing:1px;margin-bottom:14px;display:flex;align-items:center;gap:8px}
.ct::after{content:'';flex:1;height:1px;background:var(--bor)}
table{width:100%;border-collapse:collapse;font-size:12.5px}
th{text-align:right;padding:7px 10px;color:var(--mut);font-weight:600;font-size:11px;border-bottom:1px solid var(--bor)}
td{padding:9px 10px;border-bottom:1px solid rgba(37,40,64,.5)}
tr:last-child td{border:none}tr:hover td{background:rgba(88,101,242,.04)}
.badge{display:inline-block;padding:2px 7px;border-radius:5px;font-size:11px;font-weight:700}
.badge.sent{background:rgba(87,242,135,.15);color:var(--grn)}.badge.failed{background:rgba(237,66,69,.15);color:var(--red)}.badge.pending{background:rgba(250,166,26,.15);color:var(--ylw)}
.field{margin-bottom:14px}
label{display:block;font-size:11px;font-weight:700;color:var(--mut);margin-bottom:6px;text-transform:uppercase;letter-spacing:.5px}
input,textarea,select{width:100%;background:var(--sur);border:1.5px solid var(--bor);border-radius:9px;padding:10px 13px;color:var(--txt);font-family:'Cairo',sans-serif;font-size:13px;transition:border-color .2s,box-shadow .2s;outline:none;direction:rtl}
input:focus,textarea:focus,select:focus{border-color:var(--acc);box-shadow:0 0 0 3px var(--glow)}
textarea{min-height:80px;resize:vertical}
.fr{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.btn{padding:10px 20px;border:none;border-radius:9px;font-family:'Cairo',sans-serif;font-size:13px;font-weight:700;cursor:pointer;transition:all .2s;display:inline-flex;align-items:center;gap:7px}
.btn-p{background:linear-gradient(135deg,var(--acc),var(--acc2));color:#fff;box-shadow:0 4px 15px var(--glow)}
.btn-p:hover{transform:translateY(-1px);filter:brightness(1.1)}
.btn-d{background:rgba(237,66,69,.15);color:var(--red);border:1px solid rgba(237,66,69,.3)}
.btn-d:hover{background:rgba(237,66,69,.25)}
.btn-sm{padding:5px 11px;font-size:11px}
.bar-chart{display:flex;align-items:flex-end;gap:7px;height:90px;padding-top:6px}
.bw{flex:1;display:flex;flex-direction:column;align-items:center;gap:3px}
.bar{width:100%;background:linear-gradient(to top,var(--acc),var(--acc2));border-radius:3px 3px 0 0;min-height:3px;transition:height .5s ease}
.bl{font-size:9px;color:var(--mut)}.bv{font-size:10px;color:var(--txt);font-weight:600}
.ci{display:flex;align-items:center;gap:9px;margin-bottom:10px}
.cn{font-size:12px;font-weight:700;min-width:100px;color:var(--acc2)}
.cbw{flex:1;background:var(--sur);border-radius:5px;height:7px;overflow:hidden}
.cb{height:100%;background:linear-gradient(90deg,var(--acc),var(--cyn));border-radius:5px;transition:width .8s ease}
.cc{font-size:11px;color:var(--mut);min-width:26px;text-align:left}
.codebox{background:var(--sur);border:1px solid var(--bor);border-radius:9px;padding:13px 15px;font-family:monospace;font-size:11.5px;direction:ltr;color:#a8b4d8;line-height:1.8;overflow-x:auto}
.codebox .k{color:#7289da}.codebox .v{color:#57f287}.codebox .s{color:#faa61a}
#ngrok-url{background:rgba(88,101,242,.08);border:1px solid rgba(88,101,242,.3);border-radius:9px;padding:10px 14px;font-size:13px;color:var(--acc2);font-weight:700;word-break:break-all;display:none}
#toast{position:fixed;bottom:22px;left:50%;transform:translateX(-50%) translateY(60px);background:var(--card);border:1px solid var(--bor);border-radius:11px;padding:11px 22px;font-size:13px;font-weight:600;box-shadow:0 8px 30px rgba(0,0,0,.4);transition:transform .3s;z-index:999}
#toast.show{transform:translateX(-50%) translateY(0)}
#toast.success{border-color:rgba(87,242,135,.4);color:var(--grn)}
#toast.error{border-color:rgba(237,66,69,.4);color:var(--red)}
@media(max-width:900px){.sg{grid-template-columns:1fr 1fr}.cr{grid-template-columns:1fr}.fr{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="sidebar">
  <div class="logo"><h2>🤖 Discord Bot Pro</h2><p>لوحة التحكم v3</p></div>
  <nav>
    <div class="ni active" onclick="show('stats',this)"><span class="ni-icon">📊</span>الإحصائيات</div>
    <div class="ni" onclick="show('send',this)"><span class="ni-icon">📤</span>إرسال رسالة</div>
    <div class="ni" onclick="show('schedule',this)"><span class="ni-icon">📅</span>جدولة رسائل</div>
    <div class="ni" onclick="show('roles',this)"><span class="ni-icon">🎭</span>إدارة الرتب</div>
    <div class="ni" onclick="show('log',this)"><span class="ni-icon">📋</span>سجل الرسائل</div>
    <div class="ni" onclick="show('webhook',this)"><span class="ni-icon">🔔</span>Webhook</div>
  </nav>
  <div class="sf"><span class="dot"></span>البوت شغال</div>
</div>

<div class="main">

<!-- Stats -->
<div class="tab active" id="tab-stats">
  <div class="ph"><h1>📊 الإحصائيات</h1><p>نظرة عامة على أداء البوت</p></div>
  <div class="sg">
    <div class="sc b"><div class="si">📤</div><div class="sn" id="s-msg">-</div><div class="sl">رسائل مرسلة</div></div>
    <div class="sc g"><div class="si">🎉</div><div class="sn" id="s-wel">-</div><div class="sl">ترحيبات</div></div>
    <div class="sc y"><div class="si">📅</div><div class="sn" id="s-sch">-</div><div class="sl">مجدولة</div></div>
    <div class="sc c"><div class="si">🌐</div><div class="sn" id="s-gui">-</div><div class="sl">سيرفرات</div></div>
  </div>
  <div class="cr">
    <div class="card"><div class="ct">📈 آخر 7 أيام</div><div class="bar-chart" id="barchart">...</div></div>
    <div class="card"><div class="ct">⚡ أكثر الأوامر</div><div id="cmdchart">...</div></div>
  </div>
  <div class="card"><div class="ct">🕐 آخر الرسائل</div>
    <table><thead><tr><th>الأمر</th><th>الرسالة</th><th>الحالة</th><th>الوقت</th></tr></thead>
    <tbody id="recent">...</tbody></table>
  </div>
</div>

<!-- Send -->
<div class="tab" id="tab-send">
  <div class="ph"><h1>📤 إرسال رسالة</h1><p>أرسل رسالة لأي قناة مباشرة</p></div>
  <div class="card">
    <div class="field"><label>Channel ID</label><input id="s-ch" placeholder="1234567890123456789"/></div>
    <div class="field"><label>المنشن</label>
      <select id="s-mn"><option value="">بدون منشن</option><option value="@everyone">@everyone</option><option value="@here">@here</option></select>
    </div>
    <div class="field"><label>الرسالة</label><textarea id="s-ct" placeholder="اكتب الرسالة..."></textarea></div>
    <button class="btn btn-p" onclick="doSend()">🚀 إرسال الآن</button>
  </div>
</div>

<!-- Schedule -->
<div class="tab" id="tab-schedule">
  <div class="ph"><h1>📅 جدولة رسائل</h1><p>حدد وقت وتتنشر تلقائي</p></div>
  <div class="card">
    <div class="fr">
      <div class="field"><label>Channel ID</label><input id="sc-ch" placeholder="1234567890123456789"/></div>
      <div class="field"><label>المنشن</label>
        <select id="sc-mn"><option value="">بدون منشن</option><option value="@everyone">@everyone</option><option value="@here">@here</option></select>
      </div>
    </div>
    <div class="field"><label>الرسالة</label><textarea id="sc-ct" placeholder="نص الرسالة المجدولة..."></textarea></div>
    <div class="field"><label>التاريخ والوقت</label><input type="datetime-local" id="sc-tm"/></div>
    <button class="btn btn-p" onclick="doSchedule()">📅 إضافة جدولة</button>
  </div>
  <div class="card"><div class="ct">📋 الجدولات</div>
    <table><thead><tr><th>#</th><th>الرسالة</th><th>الوقت</th><th>الحالة</th><th>-</th></tr></thead>
    <tbody id="sch-table">...</tbody></table>
  </div>
</div>

<!-- Roles -->
<div class="tab" id="tab-roles">
  <div class="ph"><h1>🎭 إدارة الرتب</h1><p>أعطِ أو اسحب رتبة من أي عضو</p></div>
  <div class="cr">
    <div class="card">
      <div class="ct">✅ إعطاء رتبة</div>
      <div class="field"><label>Guild ID (السيرفر)</label><input id="gr-gid" placeholder="Server ID"/></div>
      <div class="field"><label>User ID</label><input id="gr-uid" placeholder="User ID"/></div>
      <div class="field"><label>Role ID</label><input id="gr-rid" placeholder="Role ID"/></div>
      <button class="btn btn-p" onclick="doGiveRole()">✅ إعطاء الرتبة</button>
    </div>
    <div class="card">
      <div class="ct">❌ سحب رتبة</div>
      <div class="field"><label>Guild ID (السيرفر)</label><input id="tr-gid" placeholder="Server ID"/></div>
      <div class="field"><label>User ID</label><input id="tr-uid" placeholder="User ID"/></div>
      <div class="field"><label>Role ID</label><input id="tr-rid" placeholder="Role ID"/></div>
      <button class="btn btn-d" onclick="doTakeRole()">❌ سحب الرتبة</button>
    </div>
  </div>
</div>

<!-- Log -->
<div class="tab" id="tab-log">
  <div class="ph"><h1>📋 سجل الرسائل</h1></div>
  <div class="card">
    <table><thead><tr><th>#</th><th>الأمر</th><th>الرسالة</th><th>السيرفر</th><th>الحالة</th><th>الوقت</th></tr></thead>
    <tbody id="log-tb">...</tbody></table>
  </div>
</div>

<!-- Webhook -->
<div class="tab" id="tab-webhook">
  <div class="ph"><h1>🔔 Webhook</h1><p>أرسل من أي تطبيق خارجي</p></div>
  <div class="card">
    <div class="ct">🌐 الرابط العام (ngrok)</div>
    <div id="ngrok-url">جاري التحميل...</div>
    <p style="font-size:12px;color:var(--mut);margin-top:8px">هذا الرابط يتغير كل ما تعيد تشغيل البوت (نسخة مجانية)</p>
  </div>
  <div class="card">
    <div class="ct">📝 معلومات الاتصال</div>
    <div class="codebox">
<span class="k">URL:</span>    <span class="v" id="wh-url">http://localhost:${config.dashboardPort}/webhook</span>
<span class="k">Method:</span> <span class="v">POST</span>
<span class="k">Header:</span> <span class="s">x-webhook-secret: ${config.webhookSecret}</span>
<span class="k">Body:</span>
{
  <span class="k">"channelId":</span>   <span class="s">"1234567890"</span>,
  <span class="k">"content":</span>    <span class="s">"مرحبا!"</span>,
  <span class="k">"mentionType":</span> <span class="s">"@everyone"</span>
}
    </div>
  </div>
  <div class="card">
    <div class="ct">🧪 اختبار</div>
    <div class="field"><label>Channel ID</label><input id="wh-ch" placeholder="1234567890"/></div>
    <div class="field"><label>الرسالة</label><textarea id="wh-ct" placeholder="رسالة تجريبية..."></textarea></div>
    <button class="btn btn-p" onclick="doWebhook()">🔔 اختبار</button>
  </div>
</div>

</div><!-- end main -->
<div id="toast"></div>

<script>
function show(name,el){
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.ni').forEach(n=>n.classList.remove('active'));
  document.getElementById('tab-'+name).classList.add('active');
  el.classList.add('active');
  if(name==='stats')loadStats();
  if(name==='log')loadLog();
  if(name==='schedule')loadSchedules();
}
function toast(msg,type='success'){
  const t=document.getElementById('toast');
  t.textContent=msg;t.className='show '+type;
  setTimeout(()=>t.className='',3000);
}
async function loadStats(){
  const d=await fetch('/api/stats').then(r=>r.json());
  document.getElementById('s-msg').textContent=d.totalMessages;
  document.getElementById('s-wel').textContent=d.totalWelcome;
  document.getElementById('s-sch').textContent=d.totalScheduled;
  document.getElementById('s-gui').textContent=d.guilds.length;
  const bc=document.getElementById('barchart');
  if(d.last7Days.length){
    const mx=Math.max(...d.last7Days.map(x=>x.count),1);
    bc.innerHTML=d.last7Days.map(x=>\`<div class="bw"><div class="bv">\${x.count}</div><div class="bar" style="height:\${Math.max((x.count/mx)*75,3)}px"></div><div class="bl">\${x.date.slice(5)}</div></div>\`).join('');
  } else bc.innerHTML='<p style="color:var(--mut);font-size:12px">لا بيانات بعد</p>';
  const cc=document.getElementById('cmdchart');
  if(d.topCommands.length){
    const mx=Math.max(...d.topCommands.map(x=>x.count),1);
    cc.innerHTML=d.topCommands.map(x=>\`<div class="ci"><span class="cn">\${x.command}</span><div class="cbw"><div class="cb" style="width:\${(x.count/mx)*100}%"></div></div><span class="cc">\${x.count}</span></div>\`).join('');
  } else cc.innerHTML='<p style="color:var(--mut);font-size:12px">لا بيانات بعد</p>';
  const rb=document.getElementById('recent');
  rb.innerHTML=d.recentMessages.length
    ?d.recentMessages.map(m=>\`<tr><td style="color:var(--acc2)">\${m.command||'-'}</td><td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">\${m.content||'-'}</td><td><span class="badge \${m.status}">\${m.status}</span></td><td style="color:var(--mut);font-size:11px">\${new Date(m.created_at).toLocaleString('ar')}</td></tr>\`).join('')
    :'<tr><td colspan="4" style="text-align:center;color:var(--mut)">لا رسائل بعد</td></tr>';
}
async function loadLog(){
  const d=await fetch('/api/messages').then(r=>r.json());
  document.getElementById('log-tb').innerHTML=d.length
    ?d.map(m=>\`<tr><td style="color:var(--mut)">\${m.id}</td><td style="color:var(--acc2)">\${m.command||'-'}</td><td style="max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">\${m.content||'-'}</td><td style="color:var(--mut)">\${m.guild_name||'-'}</td><td><span class="badge \${m.status}">\${m.status}</span></td><td style="color:var(--mut);font-size:11px">\${new Date(m.created_at).toLocaleString('ar')}</td></tr>\`).join('')
    :'<tr><td colspan="6" style="text-align:center;color:var(--mut)">لا سجلات</td></tr>';
}
async function loadSchedules(){
  const d=await fetch('/api/schedules').then(r=>r.json());
  document.getElementById('sch-table').innerHTML=d.length
    ?d.map(s=>\`<tr><td style="color:var(--mut)">\${s.id}</td><td style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">\${s.content}</td><td style="font-size:11px">\${new Date(s.schedule_time).toLocaleString('ar')}</td><td><span class="badge \${s.status}">\${s.status}</span></td><td><button class="btn btn-d btn-sm" onclick="delSch(\${s.id})">🗑</button></td></tr>\`).join('')
    :'<tr><td colspan="5" style="text-align:center;color:var(--mut)">لا جدولات</td></tr>';
}
async function doSend(){
  const ch=document.getElementById('s-ch').value.trim();
  const ct=document.getElementById('s-ct').value.trim();
  const mn=document.getElementById('s-mn').value;
  if(!ch||!ct)return toast('يرجى ملء جميع الحقول','error');
  const r=await fetch('/api/send',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({channelId:ch,content:ct,mentionType:mn})});
  const d=await r.json();
  if(d.success){toast('✅ تم الإرسال!');document.getElementById('s-ct').value='';}
  else toast('❌ '+d.error,'error');
}
async function doSchedule(){
  const ch=document.getElementById('sc-ch').value.trim();
  const ct=document.getElementById('sc-ct').value.trim();
  const mn=document.getElementById('sc-mn').value;
  const tm=document.getElementById('sc-tm').value;
  if(!ch||!ct||!tm)return toast('يرجى ملء جميع الحقول','error');
  const r=await fetch('/api/schedule',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({channelId:ch,content:ct,mentionType:mn,scheduleTime:new Date(tm).toISOString()})});
  const d=await r.json();
  if(d.success){toast('✅ تمت الجدولة!');loadSchedules();}
  else toast('❌ '+d.error,'error');
}
async function delSch(id){
  await fetch('/api/schedule/'+id,{method:'DELETE'});
  toast('🗑 تم الحذف');loadSchedules();
}
async function doGiveRole(){
  const gid=document.getElementById('gr-gid').value.trim();
  const uid=document.getElementById('gr-uid').value.trim();
  const rid=document.getElementById('gr-rid').value.trim();
  if(!gid||!uid||!rid)return toast('يرجى ملء جميع الحقول','error');
  const r=await fetch('/api/giverole',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({guildId:gid,userId:uid,roleId:rid})});
  const d=await r.json();
  if(d.success)toast('✅ تم إعطاء الرتبة لـ '+d.username);
  else toast('❌ '+d.error,'error');
}
async function doTakeRole(){
  const gid=document.getElementById('tr-gid').value.trim();
  const uid=document.getElementById('tr-uid').value.trim();
  const rid=document.getElementById('tr-rid').value.trim();
  if(!gid||!uid||!rid)return toast('يرجى ملء جميع الحقول','error');
  const r=await fetch('/api/takerole',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({guildId:gid,userId:uid,roleId:rid})});
  const d=await r.json();
  if(d.success)toast('✅ تم سحب الرتبة من '+d.username);
  else toast('❌ '+d.error,'error');
}
async function doWebhook(){
  const ch=document.getElementById('wh-ch').value.trim();
  const ct=document.getElementById('wh-ct').value.trim();
  if(!ch||!ct)return toast('يرجى ملء جميع الحقول','error');
  const r=await fetch('/webhook',{method:'POST',headers:{'Content-Type':'application/json','x-webhook-secret':'${config.webhookSecret}'},body:JSON.stringify({channelId:ch,content:ct})});
  const d=await r.json();
  if(d.success)toast('✅ تم الإرسال عبر Webhook!');
  else toast('❌ '+d.error,'error');
}
// تحميل ngrok url
async function loadNgrokUrl(){
  try{
    const r=await fetch('http://localhost:4040/api/tunnels');
    const d=await r.json();
    const url=d.tunnels?.[0]?.public_url;
    if(url){
      document.getElementById('ngrok-url').style.display='block';
      document.getElementById('ngrok-url').textContent='🌐 '+url;
      document.getElementById('wh-url').textContent=url+'/webhook';
    }
  }catch(e){}
}
loadStats();
loadNgrokUrl();
setInterval(loadStats,30000);
</script>
</body></html>`;}

module.exports=app;
