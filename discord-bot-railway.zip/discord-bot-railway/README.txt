==================================================
   🤖 Discord Bot Pro v4 — طريقة التشغيل
==================================================

🚀 التشغيل السريع (Windows):
  ✅ دبل كليك على: تشغيل.bat
     يثبت كل شيء ويشغل البوت تلقائياً!

--------------------------------------------------
🔧 التشغيل اليدوي:

1. عدّل config.json
2. npm install
3. npm install -g pm2
4. pm2 start ecosystem.config.js
5. pm2 save

--------------------------------------------------
📋 أوامر PM2:

  pm2 list                  - حالة البوت
  pm2 logs discord-bot      - عرض اللوق
  pm2 restart discord-bot   - إعادة تشغيل
  pm2 stop discord-bot      - إيقاف

--------------------------------------------------
📖 الأوامر في Discord:

  !send <ch_id> <رسالة>
  !everyone <ch_id> <رسالة>
  !here <ch_id> <رسالة>
  !role <ch_id> <role_id> <رسالة>
  !user <ch_id> <user_id> <رسالة>
  !announce <ch_id> <رسالة>
  !pin <ch_id> <رسالة>
  !unpin <ch_id> <msg_id>
  !giverole <user_id> <role_id>
  !takerole <user_id> <role_id>
  !schedule <ch_id> YYYY-MM-DD HH:MM @mention رسالة
  !schedules / !delschedule <ID>
  !stats / !help

--------------------------------------------------
⚙️  Discord Developer Portal:
  ✅ MESSAGE CONTENT INTENT
  ✅ SERVER MEMBERS INTENT
  ✅ صلاحيات: Send Messages, Mention Everyone,
              Manage Roles, Manage Messages
==================================================
